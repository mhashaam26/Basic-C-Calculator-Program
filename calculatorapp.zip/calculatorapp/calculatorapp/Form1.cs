﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculatorapp
{
    
        public partial class Form1 : Form 
        {
            public class Arthematic_operation
            {
                public int Add(int a, int b)
                {
                    int c = a + b;
                    return c;
                }
                public int Sub(int a, int b)
                {
                    int c = a - b;
                    return c;
                }
                public int Mul(int a, int b)
                {
                    int c = a * b;
                    return c;
                }
                public int Div(int a, int b)
                {
                    int c = a / b;
                    return c;
                }
            }
            public class Logical_operation
        {
            public int And(int x, int y)
            {
                if (x == 1 && y == 1)
                {
                    return 1;
                }
                else
                    return 0;
            }
            public int Or(int x, int y)
            {
                if (x == 1 || y == 1)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
            public int Nand(int x, int y)
            {
                if (x == 1 && y == 1)
                {
                    return 0;
                }
                else
                {
                    return 1;
                }
            }
            public int Nor(int x, int y)
            {
                if (x == 1 && y == 1)
                {
                    return 0;
                }
                if (x == 0 && y == 0)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
            public int Xor(int x, int y)
            {
                if (x == 1 && y == 1 || x == 0 && y == 0)
                {
                    return 0;
                }
                else
                {
                    return 0;
                }
            }
            public int Xnor(int x, int y)
            {
                if (x == 1 && y == 1 || x == 0 && y == 0)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
        }
            public class Temperature_operation
        {
            public double CelToFeh(double i)
            {
                double j;
                j = 1.8;
                return ((i * j) + 32);

            }
            public double KelToFeh(double i)
            {
                double j;
                j = 1.8;
                double l;
                l = (i - 273);
                return ((j * l) + 32);

            }
            public double FehToCel(double i)
            {
                double j;
                j = 0.555555;
                double l;
                l = (i - 32);
                return (j * l);


            }
            public double FehToKel(double i)
            {
                double j;
                j = (5 / 9);
                double l;
                l = (i - 32);
                double p;
                p = j * l;
                return p + 273;


            }
            public double CelToKel(double i)
            {
                return (i + 273);


            }
            public double KelToCel(double i)
            {
                return (i - 273);

            }
        }

    

            String operation = "";
            Int16 firstn, secondn;

        Logical_operation lg = new Logical_operation();
        Temperature_operation Tm = new Temperature_operation();
        Arthematic_operation ar = new Arthematic_operation();

        public Form1()
            {
                InitializeComponent();
            }

            private void button10_Click(object sender, EventArgs e)
            {
                if (textBox1.Text == "0")
                {
                    textBox1.Text = "0";
                }
                else
                {
                    string s = textBox1.Text;
                    textBox1.Text = s + Convert.ToString(0);
                }
            }

            private void button14_Click(object sender, EventArgs e)
            {
            double a;
            a = Convert.ToDouble(textBox1.Text) / Convert.ToDouble(100);
            textBox1.Text = System.Convert.ToString(a);

        }

            private void button15_Click(object sender, EventArgs e)
            {

            }

            private void button8_Click(object sender, EventArgs e)
            {
                if (textBox1.Text == "0")
                {
                    textBox1.Text = "8";
                }
                else
                {
                    string s = textBox1.Text;
                    textBox1.Text = s + Convert.ToString(8); ;
                }
            }

            private void Form1_Load(object sender, EventArgs e)
            {

            }

            private void button1_Click(object sender, EventArgs e)
            {
                if (textBox1.Text == "0")
                {
                    textBox1.Text = "1";
                }
                else
                {
                    string s = textBox1.Text;
                    textBox1.Text = s + Convert.ToString(1);
                }
            }

            private void button2_Click(object sender, EventArgs e)
            {
                if (textBox1.Text == "0")
                {
                    textBox1.Text = "2";
                }
                else
                {
                    string s = textBox1.Text;
                    textBox1.Text = s + Convert.ToString(2);
                }
            }

            private void button3_Click(object sender, EventArgs e)
            {
                if (textBox1.Text == "0")
                {
                    textBox1.Text = "3";
                }
                else
                {
                    string s = textBox1.Text;
                    textBox1.Text = s + Convert.ToString(3);
                }
            }

            private void button4_Click(object sender, EventArgs e)
            {
                if (textBox1.Text == "0")
                {
                    textBox1.Text = "4";
                }
                else
                {
                    string s = textBox1.Text;
                    textBox1.Text = s + Convert.ToString(4);
                }
            }

            private void button5_Click(object sender, EventArgs e)
            {
                if (textBox1.Text == "0")
                {
                    textBox1.Text = "5";
                }
                else
                {
                    string s = textBox1.Text;
                    textBox1.Text = s + Convert.ToString(5);
                }
            }

            private void button6_Click(object sender, EventArgs e)
            {
                if (textBox1.Text == "0")
                {
                    textBox1.Text = "6";
                }
                else
                {
                    string s = textBox1.Text;
                    textBox1.Text = s + Convert.ToString(6);
                }
            }

            private void button7_Click(object sender, EventArgs e)
            {
                if (textBox1.Text == "0")
                {
                    textBox1.Text = "7";
                }
                else
                {
                    string s = textBox1.Text;
                    textBox1.Text = s + Convert.ToString(7);
                }
            }

            private void button9_Click(object sender, EventArgs e)
            {
                if (textBox1.Text == "0")
                {
                    textBox1.Text = "9";
                }
                else
                {
                    string s = textBox1.Text;
                    textBox1.Text = s + Convert.ToString(9);
                }
            }

            private void button11_Click(object sender, EventArgs e)
            {

                textBox1.Text = "0";


            }

            private void button18_Click(object sender, EventArgs e)
            {
                textBox1.Text = "0";

            }

            private void button15_Click_1(object sender, EventArgs e)
            {
                int i = 0;
                i = Convert.ToInt32(textBox1.Text);
                i++;
                textBox1.Text = Convert.ToString(i);
            }

            private void button16_Click(object sender, EventArgs e)
            {
                int i = 0;
                i = Convert.ToInt32(textBox1.Text);
                if (i > 0)
                {
                    i--;
                    textBox1.Text = Convert.ToString(i);
                }
            }

            private void button19_Click(object sender, EventArgs e)
            {
                textBox1.Text = "0";
            }

            private void button12_Click(object sender, EventArgs e)
            {
                textBox1.Text = "0";
            }
            private void button13_Click(object sender, EventArgs e)
            {
                textBox1.Text = "0";
            }

            private void Operation_Func(object sender, EventArgs e)
            {

                Button b = (Button)sender;
                firstn = Int16.Parse(textBox1.Text);
                operation = b.Text;
                textBox1.Text = "";
            }

            private void button21_Click(object sender, EventArgs e)
            {
                if (textBox1.Text.Contains("."))
                {
                    textBox1.Text = textBox1.Text.Remove(0, 1);
                }
                else
                {
                    textBox1.Text = "-" + textBox1.Text;
                }

            }

            private void button22_Click(object sender, EventArgs e)
            {
                secondn = Convert.ToInt16(textBox1.Text);
            
                switch (operation)
                {
                    case "+":
                        textBox1.Text = Convert.ToString(ar.Add(firstn, secondn));
                        break;
                    case "-":
                        textBox1.Text = Convert.ToString(ar.Sub(firstn , secondn));
                        break;
                    case "*":
                        textBox1.Text = Convert.ToString(ar.Mul(firstn, secondn));
                        break;
                    case "/":
                        textBox1.Text = Convert.ToString(ar.Div(firstn, secondn));
                        break;
                }

            }

            private void button17_Click(object sender, EventArgs e)
            {
                Double sq = Double.Parse(textBox1.Text);
                sq = Math.Sqrt(sq);
                textBox1.Text = System.Convert.ToString(sq);
            }

            private void label1_Click(object sender, EventArgs e)
            {

            }

            private void textBox3_TextChanged(object sender, EventArgs e)
            {

            }

            private void button24_Click(object sender, EventArgs e)
            {

            }

            private void button29_Click(object sender, EventArgs e)
            {
            int a;
            int b;
            a = Int16.Parse(textBox2.Text);
            b = Int16.Parse(textBox3.Text);
            textBox4.Text = Convert.ToString(lg.Nor(a, b));
        }

            private void button36_Click(object sender, EventArgs e)
            {
            double a;
            a = Convert.ToDouble(textBox5.Text);
            textBox6.Text = Convert.ToString(Tm.KelToFeh(a));
        }

            private void label2_Click(object sender, EventArgs e)
            {

            }

        private void button23_Click(object sender, EventArgs e)
        {
            int a;
            int b;
            a = Int16.Parse( textBox2.Text);
            b = Int16.Parse(textBox3.Text);
            textBox4.Text = Convert.ToString(lg.And(a, b));



        }

        private void button24_Click_1(object sender, EventArgs e)
        {
            int a;
            int b;
            a = Int16.Parse(textBox2.Text);
            b = Int16.Parse(textBox3.Text);
            textBox4.Text = Convert.ToString(lg.Or(a, b));
        }

        private void button25_Click(object sender, EventArgs e)
        {
            int a;
            a = Int16.Parse(textBox2.Text);
            if (a == 1) 
                {
                textBox4.Text = Convert.ToString("0");
            }if (a == 0)
            {
                textBox4.Text = Convert.ToString("1");
            }
        }

        private void button28_Click(object sender, EventArgs e)
        {
            int a;
            int b;
            a = Int16.Parse(textBox2.Text);
            b = Int16.Parse(textBox3.Text);
            textBox4.Text = Convert.ToString(lg.Xor(a, b));
        }

        private void button27_Click(object sender, EventArgs e)
        {
            int a;
            int b;
            a = Int16.Parse(textBox2.Text);
            b = Int16.Parse(textBox3.Text);
            textBox4.Text = Convert.ToString(lg.Xnor(a, b));
        }

        private void button26_Click(object sender, EventArgs e)
        {
            int a;
            int b;
            a = Int16.Parse(textBox2.Text);
            b = Int16.Parse(textBox3.Text);
            textBox4.Text = Convert.ToString(lg.Nand(a, b));
        }

        private void button32_Click(object sender, EventArgs e)
        {
            double a;
            a = Convert.ToDouble(textBox5.Text);
            textBox6.Text = Convert.ToString(Tm.CelToFeh(a));
        }

        private void button33_Click(object sender, EventArgs e)
        {
            double a;
            a = Convert.ToDouble(textBox5.Text);
            textBox6.Text = Convert.ToString(Tm.CelToKel(a));
        }

        private void button34_Click(object sender, EventArgs e)
        {
            double a;
            a = Convert.ToDouble(textBox5.Text);
            textBox6.Text = Convert.ToString(Tm.FehToCel(a));
        }

        private void button35_Click(object sender, EventArgs e)
        {
            double a;
            a = Convert.ToDouble(textBox5.Text);
            textBox6.Text = Convert.ToString(Tm.FehToKel(a));
        }

        private void button37_Click(object sender, EventArgs e)
        {
            double a;
            a = Convert.ToDouble(textBox5.Text);
            textBox6.Text = Convert.ToString(Tm.KelToCel(a));
        }

        private void button20_Click(object sender, EventArgs e)
            {
                if (textBox1.Text.Length > 0)
                {
                    textBox1.Text = textBox1.Text.Remove(textBox1.Text.Length - 1, 1);
                }
                if (textBox1.Text == "")
                {
                    textBox1.Text = "0";
                }
            }
        }
    
}
